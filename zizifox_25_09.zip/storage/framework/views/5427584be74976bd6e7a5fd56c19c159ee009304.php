<?php $__env->startSection('content'); ?>
<!-- Start Banner Section -->
<section class="banner_cover text_inside" style="background: url('<?php echo e($page->banner_image); ?>');background-repeat: no-repeat;background-size: cover;background-position: top center;">
	<div class="container">
		  <?php echo $__env->make('forntend.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</section>
<!-- End Banner Section -->

<!-- Start banner Add Section  -->
<section class="inside_wrap">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-10">
				<div class="content_sec">
					<?php echo $page->content; ?>

				</div>
			</div>
			<div class="col-md-2">
				<div class="img_sec">
					<?php $innerpagerightads = \App\Models\Settings::getSettings('inner-page-right-ads');?>
          			<?php echo $innerpagerightads; ?>

				</div>
			</div>
		</div>
	</div>
</section>
<!-- End banner Add Section  -->

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('fornt-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/forntend/inner_page.blade.php ENDPATH**/ ?>