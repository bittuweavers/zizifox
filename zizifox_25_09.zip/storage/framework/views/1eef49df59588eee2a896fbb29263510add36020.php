<?php $__env->startSection('content'); ?>

          <!-- Start Main Section -->
<section class="main_section">
     <div class="container">
          <div class="row mt-5">
               <div class="col-lg-2 left_img_sec">
                    <?php $homepageleftads = \App\Models\Settings::getSettings('home-page-left-ads');?>
                   <?php echo $homepageleftads; ?>

               </div>
               <div class="col-lg-8 contant_wrap">
                    <div class="logo_sec">
                         <?php $headerLogo = \App\Models\Settings::getSettings('header-logo');?>
                         <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e($headerLogo); ?>" alt="Logo"></a>
                    </div>
                    <div class="search_sec">
                         <?php echo e(Form::open(['id'=>'search_form','method' => 'GET','route' => ['home.search.video']] )); ?>

                          <p>How to pronounce</p>
                         <select data-placeholder="Choose a Language..." name="language">
                              <option value="us">US</option>
                         </select>
                         <input name="search" type="text" placeholder="Search…" value="" autocomplete="off" maxlength="240" class="s-input js-search-field " required>
                         <?php if($search_count>5): ?>
                            <?php echo NoCaptcha::renderJs(); ?>

                             <?php echo NoCaptcha::display(); ?>

                             <div class="error_captcha"></div> 
                         <?php endif; ?>
                         <button class="search_btn" type="submit">Submit</button> 
                     <?php echo e(Form::close()); ?>    
                    </div>
                    <div class="contant_sec">
                         <?php $home_page_content = \App\Models\Settings::getSettings('home-page-content');?>
                         <p><?php echo $home_page_content; ?></p>
                    </div>
                    <div class="footer_sec">
                    <?php $homepagebottomads = \App\Models\Settings::getSettings('home-page-bottom-ads');?>
                         <?php echo $homepagebottomads; ?>

                    </div>
               </div>
               <div class="col-lg-2 right_img_sec">
                  <?php $homepagerightads = \App\Models\Settings::getSettings('home-page-right-ads');?>
                  <?php echo $homepagerightads; ?>

               </div>
          </div>
     </div>
</section>
<!-- End Main Section -->

  <?php if($search_count>5): ?>
   <script type="text/javascript">
     
     $('form').on('submit', function(e) {
  if(grecaptcha.getResponse() == "") {
    $('.error_captcha').html('Captcha is required');
   // e.preventDefault();
   // alert("You can't proceed!");
    return false;
  } else {
  //  alert("Thank you");
  }
});
   </script>

 <?php endif; ?>

<?php $__env->stopSection(); ?>	





<?php echo $__env->make('fornt-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/betterthananative.com/resources/views/forntend/home.blade.php ENDPATH**/ ?>