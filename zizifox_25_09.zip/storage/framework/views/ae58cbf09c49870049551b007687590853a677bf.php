<?php $__env->startSection('content'); ?>
    <section class="details_section">
  <div class="container">
    <div class="row">
      <div class="col-lg-10 details_wrap">
        <div class="row  align-items-center">
          <div class="col-lg-2 logo_sec">
             <?php $headerLogo = \App\Models\Settings::getSettings('header-logo');?>
                         
           <a href="<?php echo e(url('/')); ?>"> <img src="<?php echo e($headerLogo); ?>" alt="Logo"></a>
          </div>
          
          <div class="col-lg-10 search_wrap">
            

            <div class="search_sec">
              <?php echo e(Form::open(['method' => 'GET','route' => ['home.search.video']] )); ?>

              <p>How to pronounce</p>

              <select name="language"><option value="us">US</option></select>
                      <input type="text" autocomplete="off" class="s-input js-search-field " name="search" value="<?php echo e($_GET['search']); ?>" />
                      <?php if($search_count>5): ?>
                      <?php echo NoCaptcha::renderJs(); ?>

                       <?php echo NoCaptcha::display(); ?>

                       <div class="error_captcha"></div> 
                       <?php endif; ?>
                
                      <button class="search_btn" type="submit">Submit</button> 
                 <?php echo e(Form::close()); ?>       
            </div>
          
          </div>
           
        </div>
        <div class="row bottom_sec">
          <div class="col-lg-12 p-0">
         
        
             <?php if(is_object($videos)): ?>
            <div class="heading_sec">How to Pronounce <?php echo e($_GET['search']); ?> in English(<?php echo e($page); ?> out <?php echo e($video_count); ?> )</div>
              <?php  

              $video_id =  $videos->id;
              $youtube_video_id =  $videos->yt_video_id;
              $video_time =  $videos->captions[0]->time_sec;
              $videos_caption = (new App\Models\VideosCaption)->getallvideocaption($video_id);
              //$videos_caption = $videos->captions;
              $video_view_count = (new App\Models\VideoViews)->getcountvideoview($video_id);

              if($video_view_count>0){}
              else{
               $save_view = (new App\Models\VideoViews)->saveviewvideo($video_id);
                }
             
               ?>
              <div class="video_sec">
                 <div id="player"></div>

                        <?php
                         $str = htmlspecialchars_decode($videos->captions[0]->caption_text, ENT_QUOTES); 
                          $output1 = preg_replace_callback("/(&#[0-9]+;)/", function($m) { return mb_convert_encoding($m[1], "UTF-8", "HTML-ENTITIES"); }, $str); ?> 
              </div>
              <?php  $keyword = $_GET['search']; ?>
              <h3 id="caption_txt"><?php echo preg_replace("/\w*?$keyword\w*/i", "<b class='highliht_text'>$0</b>", $output1); ?></h3>
               
               <?php if($videos_caption): ?>
               <ul style="display:none;" class="caption_text">
                    <?php $__currentLoopData = $videos_caption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <?php
                         $str1 = htmlspecialchars_decode($caption->caption_text, ENT_QUOTES); 
                          $output = preg_replace_callback("/(&#[0-9]+;)/", function($m) { return mb_convert_encoding($m[1], "UTF-8", "HTML-ENTITIES"); }, $str1); ?> 
           
                    <li id='cap_<?php echo e($caption->time_sec*100); ?>' data-start="<?php echo e(floor($caption->time_sec)); ?>" data-duration="<?php echo e($caption->duration); ?>" data-end=<?php echo e($caption->time_sec+$caption->duration); ?>><?php echo preg_replace("/\w*?$keyword\w*/i", "<b class='highliht_text'>$0</b>", $output); ?></li>
                      
                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul> 
                  <?php endif; ?>
                
                  <div class="button_sec d-flex justify-content-between">
                      <?php
                          ($page == 1) ? $pervious_page =1 : $pervious_page = $page-1;
                         
                         ?>
                      <span class="<?php echo e(($page == 1) ? ' disabled' : ''); ?>" >
                      <a href="<?php echo e(url('search?language='.$_GET['language'].'&search='.$_GET['search'].'&page='.$pervious_page)); ?>" class="previous_btn"><i class="fa fa-step-backward" aria-hidden="true"></i></a>
                      </span>
                      <div>
                        <a href="javascript:void(0)" id="play-btn-video"  class="pause_btn"><i id="play-btn" class="fa fa-pause" aria-hidden="true"></i></a>
                      </div>
                      <span <?php if($next_video_id->count()>0){  $next_page = $page+1 ?> <?php }else{  $next_page = $page?> class="disabled" <?php } ?> >
                      <a href="<?php echo e(url('search?language='.$_GET['language'].'&search='.$_GET['search'].'&page='.$next_page)); ?>" class="next_icon"><i class="fa fa-step-forward" aria-hidden="true"></i></a>
                      </span>
                  </div>
              <?php else: ?>
               <div class="not_found">No Result Found</div>    
              <?php endif; ?>    
          </div>
        </div>
      </div>
      <div class="col-lg-2 banner_wrap">
         <?php $searchpagerightads = \App\Models\Settings::getSettings('search-page-right-ads');?>
                  <?php echo $searchpagerightads; ?>

      </div>
    </div>
  </div>
</section> 
  <?php if(is_object($videos)): ?>

 <script>
      var i_count=0;
      var player;
      function onYouTubeIframeAPIReady() {
        player = new YT.Player('player', {
          height: '417',
          width: '100%',
          videoId: '<?php echo  $youtube_video_id;  ?>',
          playerVars: { 'autoplay': 1, 'controls': 2,'iv_load_policy':3,'playsinline':1,'rel':0,'showinfo':0,'start':'<?php  echo floor($video_time); ?>' },
           events: {
                'onReady': initialize,
                'onStateChange': onPlayerStateChange
            }
         
        });
      
      }
      var time_update_interval;

 function initialize() {
    time_update_interval = setInterval(function() {
            updateTimerDisplay();
        },1000);

    }



  
    function updateTimerDisplay(){
      if(i_count>0){
      var youtube_time = Math.round(player.getCurrentTime());
      
        var $this = $('ul li[data-start="'+youtube_time+'"]');
          if($this.text()){
            $('#caption_txt').html($this.html());

          }else{
          //  console.log(2);
          }
        }
        i_count =i_count+1;
    }


        function onPlayerStateChange(event) {

        switch (event.data) {
            case YT.PlayerState.PLAYING:
                initialize();
                $('#play-btn').removeClass('fa fa-play');
                $('#play-btn').addClass('fa fa-pause');
                
                break;
            case YT.PlayerState.PAUSED:
                clearInterval(time_update_interval);
                $('#play-btn').removeClass('fa fa-pause');
                $('#play-btn').addClass('fa fa-play');
                 
                break;
            default:
                return;

        }
    }


    </script>
   
   <?php endif; ?> 
<?php if($search_count>5): ?>
   <script type="text/javascript">
     
     $('form').on('submit', function(e) {
  if(grecaptcha.getResponse() == "") {
    $('.error_captcha').html('Captcha is required');
   // e.preventDefault();
   // alert("You can't proceed!");
    return false;
  } else {
  //  alert("Thank you");
  }
});
   </script>

 <?php endif; ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('fornt-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dh_skf5h8/workspace1.weavers-web.com/dictionary/resources/views/forntend/search.blade.php ENDPATH**/ ?>