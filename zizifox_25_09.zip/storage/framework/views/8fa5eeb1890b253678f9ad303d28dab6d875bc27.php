

<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="container-fluid">
			<div class="search-wrap">
				<div class="row">
				<h4 style="text-align: center;">Stored Videos</h4>
				</div>
			</div>
			<div class="row">

			</div>
			<div class="row">
				<div class="col-md-12">

					<div class="card">
						<?php $no = 1; ?>
						<div class="content table-responsive table-full-width">
							<table  class="table table-bordered table-hover table-striped <?php echo e(count($videos) > 0 ? 'datatable' : ''); ?> ">
								<thead>
									
									<th>Sl No</th>
									<th>Video Name</th>
									<th>View Count</th>
									<th>Video Id</th>
							
									<th >Action</th>
									
								</thead>
								<tbody>
									<?php if(isset($videos) && is_object($videos)): ?>
										<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr data-entry-id="<?php echo e($val->id); ?>">
												
												<td><?php echo e($no); ?></td>
												<td><?php echo e($val->yt_video_name); ?></td>
												<td>0</td>
												<td><?php echo e($val->yt_video_id); ?></td>
												<td colspan="2">

														<?php echo Form::open(array(
															'style' => 'display: inline-block;',
															'method' => 'DELETE',
															'onsubmit' => "return confirm('Are you sure ?');",
															'route' => ['admin.videos.destroy', $val->id])); ?>

															<?php echo Form::submit('Delete', array('class' => 'btn btn-xs btn-danger')); ?>

														<?php echo Form::close(); ?>

												
			                                      	<a class="btn btn btn-xs btn-info " href="<?php echo e(url('admin/videos/view')); ?>/<?php echo e($val->id); ?>">Show</a>
			                                        <a class="btn btn btn-xs btn-info video_status" href="javascript:void(0)" data-id="<?php echo e($val->id); ?>"><?php if($val->status=='1'): ?> <?php echo e('Disable'); ?> <?php else: ?> <?php echo e('Enable'); ?> <?php endif; ?></a>	   	
												</td>
											</tr>
											<?php $no++; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									<?php endif; ?>
								</tbody>	
							</table>
						
                        </div>

                    </div>
                   
                </div>
            </div>
        </div>

    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script>

    	$(document).ready(function(){
        	
            $('.video_status').on('click', function(event){
            	if(confirm('Are you sure to change the status?')){

                id = $(this).data('id');
                var $this = $(this);
                $.ajax({
                    type: 'POST',
                    url:"<?php echo e(URL::route('admin.videos.changeStatus')); ?>",
					data: {
					        "_token": "<?php echo e(csrf_token()); ?>",
					        "id": id
					        },
                    success: function(data) {
                    	$this.html(data);
                        // empty
                    },
                });
            }
            });
          
        });

 	</script>
<?php $__env->stopSection(); ?>	





<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Dictionary/resources/views/admin/videos/index.blade.php ENDPATH**/ ?>