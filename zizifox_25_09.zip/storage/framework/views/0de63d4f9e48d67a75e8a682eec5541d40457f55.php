<?php $__env->startSection('content'); ?>
			<div class="row">

				<div class="col-sm-12">
					<table class="table table-bordered table-striped">
			    		<thead>
			      			<tr>
			        			<h4 style="text-align: center;">Video Details</h4>
			      			</tr>
			    		</thead>					
			    		<tbody>
			      			<tr>
			        			<td>Video Id</td>
			        			<td><?php echo e($videos->yt_video_id); ?></td>
			         		</tr>
			        		<tr> 
			        			<td>Video Name</td>
			        			<td><?php echo e($videos->yt_video_name); ?></td>
			         		</tr>
			         		<tr> 
			        			<td>Video Url</td>
			        			<td><?php echo e($videos->yt_video_url); ?></td>
			         		</tr>
			         		<tr> 
			        			<td>Channel Name</td>
			        			<td><?php echo $channel_name = \App\Models\Channel::get_channel_name( $videos->channels_id);?></td>
			         		</tr>
			         		
			         		<tr> 
			        			<td>Status</td>
			        			<?php if($videos->status=='1'): ?>
			        			<td><?php echo e('Enable'); ?></td>
			        			<?php else: ?> 
			        			<td><?php echo e('Disable'); ?></td>
			        			<?php endif; ?>
			     			</tr>
												
						</tbody>
			      	</table>					
				</div>			
			</div>	
				<?php
					 $vi_cap = $videos->caption;
              		 $cap_arr = explode("|||",$vi_cap);
				 ?>

			<div class="row">

				<div class="col-sm-12">
				<div class="card">

						<?php $no = 1; 

						?>
						<div class="content table-responsive table-full-width">
								<h4 style="text-align: center;">Video Caption</h4>
							<table  class="table table-bordered table-hover table-striped <?php echo e(count($cap_arr) > 0 ? 'datatable' : ''); ?> ">
								<thead>
									
									<th>ID</th>
									<th>Caption Text</th>
									<th>Time</th>
									<th>Duration</th>
							
									
									
								</thead>
								<tbody>
									<?php if(count($cap_arr) > 0): ?>
										<?php $__currentLoopData = $cap_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr >
												
												<td><?php echo e($no); ?></td>
												   <?php
												
												   	$cap_arr2 = explode("@@@",$val); 
								                    $video_time = $cap_arr2[0];
								                     $start_vid_caption = $cap_arr2[2];
							                         $str1 = htmlspecialchars_decode($start_vid_caption, ENT_QUOTES); 
							                          $output = preg_replace_callback("/(&#[0-9]+;)/", function($m) { return mb_convert_encoding($m[1], "UTF-8", "HTML-ENTITIES"); }, $str1); 
							                          ?> 
												<td><?php echo e($output); ?></td>
												<td><?php echo e($video_time); ?></td>
												<td><?php echo e($cap_arr2[1]); ?></td>
												
												
											</tr>
											<?php $no++; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									<?php endif; ?>
								</tbody>	
							</table>
						
                        </div>

                    </div>					
				</div>			
			</div>
	<style>
	ul.user-info {
		padding: 0;
	}
	.user-info>li {
		list-style: none;
		padding: 3px;
	}
	.user-info>li>strong {
		margin-right: 10px;
	}
	</style>

<?php $__env->stopSection(); ?>	
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/videos/show.blade.php ENDPATH**/ ?>