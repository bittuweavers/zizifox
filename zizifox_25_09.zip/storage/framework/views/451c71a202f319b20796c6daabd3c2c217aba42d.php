<?php $__env->startSection('content'); ?>


    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
    <style type="text/css">
    	.card{
     margin: 20px 20px 20px 20px;
    font-size: 17px;
    padding: 10px 0px 9px 20px;
    	}
    </style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>