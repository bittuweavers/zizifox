<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
	<div class="form">
		<div class="main-div cust">
        <div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="title">Update Language</h4>
			</div>
			<?php echo e(Form::model($language, ['method' => 'PUT', 'route' => ['admin.languages.update', $language->id]])); ?>

				<div class="panel-body">
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('lang_name', 'Language Name*', ['class' => 'control-label'])); ?>


								<?php echo e(Form::text('lang_name', old('lang_name'), ['class' => 'form-control', 'placeholder' => 'Title', 'required' => ''])); ?>

								<p class="help-block"></p>
								<?php if($errors->has('lang_name')): ?>
									<p class="help-block">
										<?php echo e($errors->first('lang_name')); ?>

									</p>
								<?php endif; ?>
						</div>
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('lang_code', 'Language Code*', ['class' => 'control-label'])); ?>


								<?php echo e(Form::text('lang_code', old('lang_code'), ['class' => 'form-control', 'placeholder' => 'Language Code', 'required' => ''])); ?>

								<p class="help-block"></p>
								<?php if($errors->has('lang_code')): ?>
									<p class="help-block">
										<?php echo e($errors->first('lang_code')); ?>

									</p>
								<?php endif; ?>
						</div>						
					</div>		
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::submit('Update', ['class' => 'btn btn-primary'])); ?>

						</div>
					</div>
				</div>
			<?php echo e(Form::close()); ?>


		</div>
	</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/languages/edit.blade.php ENDPATH**/ ?>