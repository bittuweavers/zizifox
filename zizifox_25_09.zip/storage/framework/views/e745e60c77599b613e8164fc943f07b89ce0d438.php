<?php $__env->startSection('content'); ?>

<!-- Start View Section -->
<!-- Start Banner Section -->
<section class="banner_cover" <?php if($banner){ ?> style="background: url('<?php echo e($banner->banner_url); ?>');background-repeat: no-repeat;background-size: cover;background-position: top center;" <?php } ?>>
  <div class="container">
    <?php echo $__env->make('forntend.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2>How to pronounce</h2>
    <?php echo e(Form::open(['id'=>'search_form','method' => 'GET','route' => ['home.search.video']] )); ?>

    <div class="search_sec"> 
      <div class="search">
         <input name="search" type="search" placeholder="Enter a word" value="" autocomplete="off" maxlength="100" class="s-input js-search-field " required>
        <div class="option_box">
         <select data-placeholder="Choose a Language..." id="lan-select" name="language">
              <?php if($language->count()>0): ?>
                <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($val->lang_code=='en'){
                        $lang='us';
                        }else{
                        $lang=$val->lang_code;
                        } 
                  ?> 
                  <option value="<?php echo e($lang); ?>"><?php echo e($val->lang_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <?php else: ?>
                  <option value="us">US</option>      
                <?php endif; ?> 
          </select>
        </div>
      </div>
      <div class="button_sec">
        <button type="submit" class="btn_submit">Search</button>
      </div>
      <?php if($search_count>5): ?>
           <?php echo NoCaptcha::renderJs(); ?>

           <?php echo NoCaptcha::display(); ?>

             <div class="error_captcha"></div> 
       <?php endif; ?>
    </div>
    <?php echo e(Form::close()); ?>   
    <div class="content_sec">
     <?php $home_page_content = \App\Models\Settings::getSettings('home-page-content');?>
                       <?php echo $home_page_content; ?>

    </div>
  </div>
</section>
<!-- End Banner Section -->

<!-- Start banner Add Section  -->
<section class="add_sec">
  <div class="container">
    <div class="img_sec">
      <?php $homepagerightads = \App\Models\Settings::getSettings('home-page-bottom-ads');?>
          <?php echo $homepagerightads; ?>

    </div>
  </div>
</section>
<!-- End banner Add Section  -->

  <?php if($search_count>5): ?>
   <script type="text/javascript">
     
     $('form').on('submit', function(e) {
  if(grecaptcha.getResponse() == "") {
    $('.error_captcha').html('Captcha is required');
   // e.preventDefault();
   // alert("You can't proceed!");
    return false;
  } else {
  //  alert("Thank you");
  }
});
   </script>

 <?php endif; ?>

<?php $__env->stopSection(); ?>	





<?php echo $__env->make('fornt-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/forntend/home.blade.php ENDPATH**/ ?>