<?php $__env->startSection('style'); ?>
	
	<link href="<?php echo e(asset('css/uploadfile.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
	<div class='col-sm-12'>
		<h2> Add Banner</h2>

		
        <?php echo e(Form::open(['method' => 'POST','files' => true, 'route' => ['admin.banners.store']])); ?>

		
		<div class='form-group'>
			<?php echo e(Form::label('banner_title', 'Title')); ?>

			<?php echo e(Form::text('banner_title', null, ['placeholder' => 'Title', 'class' => 'form-control', 'id' => 'banner-title'])); ?>

		</div>
		<div class='form-group'>
			<?php echo e(Form::label('banner_image', 'Banner Image', ['class' => 'control-label'])); ?>		
			<div id="bannerimage">Upload</div>
			<input type="hidden" id="banner_url" class="form-control" name="banner_image" value="">
		</div>
		<div class='form-group'>
		
			<input type="checkbox" name="page_type[]" value="1">Home 
  			<input type="checkbox" name="page_type[]" value="2">Influencer Home
  			<input type="checkbox" name="page_type[]" value="3">Search Result
  			<input type="checkbox" name="page_type[]" value="4">Influencer Search Result
		</div>	
		<div class='form-group'>
			<?php echo Form::submit(trans('Save'), ['class' => 'btn btn-danger']); ?>

		</div>

		<?php echo e(Form::close()); ?>


	</div>
</div>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/jquery.uploadfile.js')); ?>"></script>

<script>
jQuery(document).ready(function() {
	jQuery("#bannerimage").uploadFile({
		url:"<?php echo e(url('admin/ajax-upload-photo')); ?>",
		fileName:"image",
		showPreview: true,
		showProgress: true,
		showError: false,
		showStatusAfterError: false,
		showFileCounter: false,
		multiple: false,
		showCancel: false,
		showAbort: false,
		dragDropStr: '',
		dragdropWidth: '28%',
		showFileSize: false,
		previewHeight: "60px",
		previewWidth: "auto",
		headers: {'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"},
		onSuccess: function (files, response, xhr, pd) {
			jQuery("#banner_url").val(response.response.file_path);
		}
	});

});	

var rand = function() {
    return Math.random().toString(36).substr(2); // remove `0.`
};

var token = function() {
    var tk = rand() + rand() + rand() + rand(); // to make it longer
    jQuery("#api_token").val(tk);
    
};

</script>
<?php $__env->stopSection(); ?>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/banner/create.blade.php ENDPATH**/ ?>