<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="container-fluid">
			<div class="search-wrap">
				<div class="row">
				<h4 style="text-align: center;">Language List</h4>
				</div>
				<div class="row">
				<a href="<?php echo e(url('admin/languages/add')); ?>" class="btn btn-success pull-right">Add Language</a>

			</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
				
					<div class="card">
						<?php
				   if(isset($_GET['page'])){
				              $no=($_GET['page']-1)*40+1;
				           
				          }else{
				            $no = 1;
				          }
          

						  ?>
						<div class="content table-responsive table-full-width">
							<table  class="table table-bordered table-hover table-striped">
								<thead>
									
									<th>Sl No</th>
									<th>Language Name</th>
									<th >Action</th>
									
								</thead>
								<tbody>
									<?php if(isset($language) && is_object($language)): ?>
										<?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr data-entry-id="<?php echo e($val->id); ?>">
												
												<td><?php echo e($no); ?></td>
												<td><?php echo e($val->lang_name); ?></td>
												<td colspan="2">
														<?php echo Form::open(array(
															'style' => 'display: inline-block;',
															'method' => 'DELETE',
															'onsubmit' => "return confirm('Are you sure ?');",
															'route' => ['admin.languages.destroy', $val->id])); ?>

															<?php echo Form::submit('Delete', array('class' => 'btn btn-xs btn-danger')); ?>

														<?php echo Form::close(); ?>

												
			                                       <a class="btn btn-xs btn-warning" href="<?php echo e(route('admin.languages.edit',[$val->id])); ?>">Edit</a> 
												</td>
											</tr>
											<?php $no++; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									<?php endif; ?>
								</tbody>	
							</table>
						
                        </div>
                        <div class="text-center">
						<?php echo e($language->links()); ?>

						</div>
                    </div>
                   
                </div>
            </div>
        </div>

    </div>

    
<?php $__env->stopSection(); ?>	





<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/languages/index.blade.php ENDPATH**/ ?>