<?php $__env->startSection('style'); ?>
<style type="text/css">
	.cust{
		    max-width: 80% !important;
	}
</style>
	<link href="<?php echo e(asset('css/uploadfile.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
	<div class="form">
		<div class="main-div cust">
        <div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="title">Update Influencer</h4>
			</div>
			<?php echo e(Form::model($influencer, ['method' => 'PUT', 'route' => ['admin.influencers.update', $influencer->id]])); ?>

				<div class="panel-body">
					<div class="row">
						
						<div class="col-md-12 form-group">
						<?php echo e(Form::label('title', 'Title*', ['class' => 'control-label'])); ?>


							<?php echo e(Form::text('title', old('title'), ['class' => 'form-control', 'placeholder' => 'Title', 'required' => ''])); ?>

							<p class="help-block"></p>
							<?php if($errors->has('title')): ?>
								<p class="help-block">
									<?php echo e($errors->first('title')); ?>

								</p>
							<?php endif; ?>
						</div>
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('description', 'Description', ['class' => 'control-label'])); ?>

							<?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control','placeholder' => 'Description','style' => 'height:150px;'])); ?>

						
						</div>
											
					</div>
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('Logo', 'Logo', ['class' => 'control-label'])); ?>

							
							<input type="text" id="logo" class="form-control" name="logo" value="<?php echo e($influencer->logo); ?>" >
							<div id="influencerslogo">Upload</div>
							<?php if($influencer->logo): ?>
							<div id="influence_image">
			        			<img src="<?php echo e($influencer->logo); ?>" alt="<?php echo e($influencer->title); ?>" width=100>
			        		</div>
			        		<?php endif; ?>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('Description Image', 'Description Image', ['class' => 'control-label'])); ?>

							
							<input type="text" id="description_image" class="form-control" name="description_image" value="<?php echo e($influencer->description_image); ?>" >
							<div id="descriptionimage">Upload</div>
							<?php if($influencer->description_image): ?>
							<div id="descr_image">
			        			<img src="<?php echo e($influencer->description_image); ?>" alt="<?php echo e($influencer->title); ?>" width=100>
			        		</div>
			        		<?php endif; ?>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('site_url', 'Site URL', ['class' => 'control-label'])); ?>

							<?php echo e(Form::text('site_url', old('site_url'), ['class' => 'form-control', 'placeholder' => 'Site URL'])); ?>

						</div>
					</div>
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('youtube_channel_url', 'Youtube Channel URL', ['class' => 'control-label'])); ?>

							<?php echo e(Form::text('youtube_channel_url', old('youtube_channel_url'), ['class' => 'form-control', 'placeholder' => 'Youtube Channel URL'])); ?>

						</div>
					</div>				
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('subscription_custom_url', 'Subscription Custom URL', ['class' => 'control-label'])); ?>

							<?php echo e(Form::text('subscription_custom_url', old('subscription_custom_url'), ['class' => 'form-control', 'placeholder' => 'Subscription Custom URL'])); ?>

						</div>
					</div>	
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::label('Channel', 'Channel', ['class' => 'control-label'])); ?>

							 <select id="channel_list" name="channel[]" class="form-control" multiple required="">
							 	<?php $channel_name = explode(',', $influencer->channels_id);
							 		  foreach ($channel_name as $key) { ?>
							 		  			<?php  $channel_name =  \App\Models\Channel::get_channel_name_by_id( $key) ?>
							 		  			<option value="<?php echo e($key); ?>" selected><?php echo e($channel_name); ?></option>
							 		  			
							 		  	<?php 	}		
							 	 ?>
							 	
							 </select>
							
						</div>
					</div>		
								
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::submit('Update', ['class' => 'btn btn-primary'])); ?>

						</div>
					</div>
				</div>
			<?php echo e(Form::close()); ?>


		</div>
	</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/jquery.uploadfile.js')); ?>"></script>
<script>
jQuery(document).ready(function() {
	jQuery("#influencerslogo").uploadFile({
		url:"<?php echo e(url('admin/ajax-upload-photo')); ?>",
		fileName:"image",
		showPreview: true,
		showProgress: true,
		showError: false,
		showStatusAfterError: false,
		showFileCounter: false,
		multiple: false,
		showCancel: false,
		showAbort: false,
		dragDropStr: '',
		dragdropWidth: '28%',
		showFileSize: false,
		previewHeight: "60px",
		previewWidth: "auto",
		headers: {'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"},
		onSuccess: function (files, response, xhr, pd) {
			jQuery('#influence_image').hide();
			jQuery("#logo").val(response.response.file_path);
		}
	});

	jQuery("#descriptionimage").uploadFile({
		url:"<?php echo e(url('admin/ajax-upload-photo')); ?>",
		fileName:"image",
		showPreview: true,
		showProgress: true,
		showError: false,
		showStatusAfterError: false,
		showFileCounter: false,
		multiple: false,
		showCancel: false,
		showAbort: false,
		dragDropStr: '',
		dragdropWidth: '28%',
		showFileSize: false,
		previewHeight: "60px",
		previewWidth: "auto",
		headers: {'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"},
		onSuccess: function (files, response, xhr, pd) {
			jQuery('#descr_image').hide();
			jQuery("#description_image").val(response.response.file_path);
		}
	});

	     jQuery('#channel_list').select2({
            placeholder: "Choose Channels...",
            minimumInputLength: 2,
            ajax: {
                url: "<?php echo e(url('admin/channel/find')); ?>",
                dataType: 'json',
                data: function (params) {
                    return {
                        q: $.trim(params.term)
                    };
                },
                processResults: function (data) {
                    return {
                        results: data
                    };
                },
                cache: true
            }
        });

});	

var rand = function() {
    return Math.random().toString(36).substr(2); // remove `0.`
};

var token = function() {
    var tk = rand() + rand() + rand() + rand(); // to make it longer
    jQuery("#api_token").val(tk);
    
};

CKEDITOR.replace('description')
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/influencers/edit.blade.php ENDPATH**/ ?>