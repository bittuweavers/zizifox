   <div class="header_sec">
    <nav class="navbar navbar-expand-md">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fa fa-bars" aria-hidden="true"></i>
      </button>

      <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">

       <?php if(Request::is('privacy-policy')): ?>
          <?php $privacymenuClass = 'active'; ?>
        <?php else: ?>
          <?php $privacymenuClass = ''; ?>
        <?php endif; ?> 
         <?php if(Request::is('developer')): ?>
          <?php $developermenuClass = 'active'; ?>
        <?php else: ?>
          <?php $developermenuClass = ''; ?>
        <?php endif; ?> 
         <?php if(Request::is('about-us')): ?>
          <?php $aboutmenuClass = 'active'; ?>
        <?php else: ?>
          <?php $aboutmenuClass = ''; ?>
        <?php endif; ?> 
        <?php if($privacymenuClass=="" && $developermenuClass =="" &&  $aboutmenuClass == ""): ?>
            <?php $homemenuClass = 'active'; ?>
        <?php else: ?>
          <?php $homemenuClass = ''; ?>
        <?php endif; ?> 
        <li class="nav-item <?php echo e($homemenuClass); ?>">
           <?php $headerLogo = \App\Models\Settings::getSettings('header-logo');?>
           <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e($headerLogo); ?>" alt="Logo"></a>
        </li>
        <li class="nav-item <?php echo e($privacymenuClass); ?>">
        <a class="nav-link" href="<?php echo e(url('/privacy-policy')); ?>">PRIVACY POLICY</a>
        </li>
        <li class="nav-item <?php echo e($developermenuClass); ?>">
        <a class="nav-link" href="<?php echo e(url('/developer')); ?>">DEVELOPER</a>
        </li>
        <li class="nav-item <?php echo e($aboutmenuClass); ?>">
        <a class="nav-link" href="<?php echo e(url('/about-us')); ?>">About Us</a>
        </li>
      </ul>
      </div>
    </nav>
    </div>
<?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/forntend/menu.blade.php ENDPATH**/ ?>