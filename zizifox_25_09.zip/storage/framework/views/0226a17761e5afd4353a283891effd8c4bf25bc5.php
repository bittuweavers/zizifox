<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-sm-12">
		<h2>Banners <a href="<?php echo e(url('admin/banners/add')); ?>" class="btn btn-success pull-right">Add Banners</a></h2>
		    <div class="col-md-6 col-md-offset-3">
				<?php if(Session::has('message')): ?>
				<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
				<?php endif; ?>
            </div>
		<div class="table-responsive">
			<table class="table table-bordered table-striped">

				<thead>
					<tr>
						<th>Title</th>
						<th>Image Url</th>
						<th>Date/Time Added</th>
						<th></th>
					</tr>
				</thead>

				<tbody>
					<?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($banner->banner_title); ?></td>
						<td><?php echo e($banner->banner_url); ?></td>
						<td><?php echo $banner->created_at; ?></td>
						<td>
							<a href="<?php echo e(url('admin/banners/edit/'.$banner->id)); ?>" class="btn btn-info pull-left" style="margin-right: 3px;">Edit</a>
							
							<?php echo Form::open(array(
								'style' => 'display: inline-block;',
								'method' => 'DELETE',
								'onsubmit' => "return confirm('Are you sure ?');",
								'route' => ['admin.banners.destroy', $banner->id])); ?>

								<?php echo Form::submit('Delete', array('class' => 'btn btn-danger')); ?>

							<?php echo Form::close(); ?>


							
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			
			</table>
			<?php echo e($banners->links()); ?>

		</div>

	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/banner/index.blade.php ENDPATH**/ ?>