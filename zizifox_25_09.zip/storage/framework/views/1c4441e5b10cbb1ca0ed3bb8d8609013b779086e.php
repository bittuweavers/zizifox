

<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="container-fluid">
			<div class="search-wrap">
				<div class="row">
				<?php $userLevel = request()->get('user-level') ?>
					<form method="GET" action ="">
						<div class="col-sm-4">
							<select name="user-level" class="form-control form-control-sm input-sm" id="user-level">
								<option value="">Select User Role</option>
								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($userLevel &&  ($userLevel == $role->id)): ?>
										<option value="<?php echo e($role->id); ?>" selected="selected"><?php echo e($role->title); ?></option>
									<?php else: ?>
										<option value="<?php echo e($role->id); ?>"><?php echo e($role->title); ?></option>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							
						</div>
						<div class="col-sm-2">
							<input type="submit" value="Submit" class="btn btn-default btn-sm btn-block search-sbt">
						</div>
					<div class="col-sm-2">
							
					</div>
				    <div class="col-md-4 ">
						<p>
							<a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-warning btn-sm btn-block ">Add User</a>
						</p>
					</div>						
					</form>
				</div>
			</div>
			<div class="row">

			</div>
			<div class="row">
				<div class="col-md-12">

					<div class="card">

						<div class="content table-responsive table-full-width">
							<table  class="table table-bordered table-hover table-striped <?php echo e(count($users) > 0 ? 'datatable' : ''); ?> ">
								<thead>
									
									<th>ID</th>
									<th>Name</th>
									<th>User Name</th>
									<th>email</th>
									<th>Role</th>
									<th>Block Count</th>
									<?php if(Request::query('user-level') ==3): ?>
										<th>Moderate</th>
									<?php endif; ?>
									<th >Action</th>
									
								</thead>
								<tbody>
									<?php if(isset($users) && is_object($users)): ?>
										<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr data-entry-id="<?php echo e($val->id); ?>">
												
												<td><?php echo e($val->id); ?></td>
												<td><?php echo e($val->name); ?></td>
												<td><?php echo e($val->username); ?></td>
												<td><?php echo e($val->email); ?></td>
												
												<td><?php echo (new App\Models\Role)->getRoleName($val->role_id); ?></td>
												<td><a class="tag" href="javascript:void(0);"><?php echo e($val->blocks); ?></a></td>
												<?php if(Request::query('user-level') ==3): ?>											
													<td class="text-center"><input type="checkbox" class="published" id="" data-id="<?php echo e($val->id); ?>" <?php if($val->is_approved): ?> checked <?php endif; ?></td>
												<?php endif; ?>
												
												<td colspan="2">
			                                       <a class="btn btn btn-xs btn-info " href="<?php echo e(url('admin/users')); ?>/<?php echo e($val->id); ?>">Show</a>															
												    <a class="btn btn-xs btn-warning" href="<?php echo e(route('admin.users.edit',[$val->id])); ?>">Edit</a>
													<?php if(Auth::user()->id != $val->id ): ?>
														<?php echo Form::open(array(
															'style' => 'display: inline-block;',
															'method' => 'DELETE',
															'onsubmit' => "return confirm('Are you sure ?');",
															'route' => ['admin.users.destroy', $val->id])); ?>

															<?php echo Form::submit('Block', array('class' => 'btn btn-xs btn-danger')); ?>

														<?php echo Form::close(); ?>

													<?php endif; ?>
												</td>
												
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									<?php endif; ?>
								</tbody>	
							</table>
						
                        </div>

                    </div>
                   
                </div>
            </div>
        </div>

    </div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
        	<?php if(Request::query('user-level') ==3){	 ?>
            $('.published').on('click', function(event){
                id = $(this).data('id');
                $.ajax({
                    type: 'POST',
                    url:"<?php echo e(URL::route('admin.changeStatus')); ?>",
					data: {
					        "_token": "<?php echo e(csrf_token()); ?>",
					        "id": id
					        },
                    success: function(data) {
                        // empty
                    },
                });
            });
            <?php } ?>
        });


                // Show a post

        
    </script>
<?php $__env->stopSection(); ?>	





<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Dictionary/resources/views/admin/users/index.blade.php ENDPATH**/ ?>