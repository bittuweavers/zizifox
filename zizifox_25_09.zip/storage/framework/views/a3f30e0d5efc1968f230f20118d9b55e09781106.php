<?php $__env->startSection('content'); ?>
    <section class="details_section">
  <div class="container">
    <div class="row">
      <div class="col-lg-10 details_wrap">
        <div class="row  align-items-center">
          <div class="col-lg-2 logo_sec">
             <?php $headerLogo = \App\Models\Settings::getSettings('header-logo');?>
                         
           <a href="<?php echo e(url('/')); ?>"> <img src="<?php echo e($headerLogo); ?>" alt="Logo"></a>
          </div>
          
          <div class="col-lg-10 search_wrap">
            

            <div class="search_sec">
              <?php echo e(Form::open(['method' => 'GET','route' => ['home.search.video']] )); ?>

              <p>How to pronounce</p>

              <select name="language"><option value="us">US</option></select>
                      <input type="text" autocomplete="off" class="s-input js-search-field " name="search" value="<?php echo e($_GET['search']); ?>" />
                      <?php if($search_count>5): ?>
                      <?php echo NoCaptcha::renderJs(); ?>

                       <?php echo NoCaptcha::display(); ?>

                       <div class="error_captcha"></div> 
                       <?php endif; ?>
                
                      <button class="search_btn" type="submit">Submit</button> 
                 <?php echo e(Form::close()); ?>       
            </div>
          
          </div>
           
        </div>
        <div class="row bottom_sec">
          <div class="col-lg-12 p-0">
                <div class="heading_sec">How to Pronounce <?php echo e($_GET['search']); ?> in English(<span id="page"><?php echo e($page); ?></span> out <?php echo e($video_count); ?> )</div>
                <div class="ajax_load" ><img src="<?php echo e(url('forntend/images/loading.gif')); ?>"></div>
                <div class="ajx-result">
                    <?php echo $__env->make('forntend.ajax_search_result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
             
          </div>
        </div>
      </div>
      <div class="col-lg-2 banner_wrap">
         <?php $searchpagerightads = \App\Models\Settings::getSettings('search-page-right-ads');?>
                  <?php echo $searchpagerightads; ?>

      </div>
    </div>
  </div>
</section> 
  
<?php if($search_count>5): ?>
   <script type="text/javascript">
     
     $('form').on('submit', function(e) {
  if(grecaptcha.getResponse() == "") {
    $('.error_captcha').html('Captcha is required');
   // e.preventDefault();
   // alert("You can't proceed!");
    return false;
  } else {
  //  alert("Thank you");
  }
});
   </script>
  

 <?php endif; ?>
<script type="text/javascript">
   $(document).ready(function()
    {
        $(document).on('click', '.pagination',function(event)
        {
              event.preventDefault();
             
             var page = $(this).find('a:first').data('page');
             var search = $(this).find('a:first').data('search');
             var id = $(this).find('a:first').data('id');
            getData(page,search,id);
        });

        $(document).ajaxStart(function(){
          $(".ajax_load").css("display", "block");
          $('a').attr('disabled',true);
        });
        $(document).ajaxComplete(function(){
          $(".ajax_load").css("display", "none");
           $('a').attr('disabled',false);
        });

  
    });
  
    function getData(page,search,id){


        jQuery.ajax(
        {
            url: "<?php echo e(url('/ajax-pagination')); ?>",
              type: "get",
             data: { page: page,search:search,id:id },
            datatype: "html"
        }).done(function(data){
            $(".ajx-result").empty().html(data);
            onYouTubeIframeAPIReady();
            $("#page").text(page);
        }).fail(function(jqXHR, ajaxOptions, thrownError){
              alert('No response from server');
        });
    }

</script>
 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('fornt-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/betterthananative.com/resources/views/forntend/search.blade.php ENDPATH**/ ?>