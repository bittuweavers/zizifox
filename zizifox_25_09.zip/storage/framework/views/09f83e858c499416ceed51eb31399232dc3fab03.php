 
 <div class="container-fluid">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="#">Admin Dashboard</a>
	</div>
	<div class="collapse navbar-collapse">
		<ul class="nav navbar-nav navbar-left">
		
		</ul>

		<ul class="nav navbar-nav navbar-right">
			<li>
				<a href="<?php echo e(route('logout')); ?>"
					onclick="event.preventDefault();
							 document.getElementById('logout-form').submit();">
					Logout
				</a>

				<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
					<?php echo e(csrf_field()); ?>

				</form>
				<!--<a href="javascript:void(0);">
					<p>Log out</p>
				</a>-->
			</li>
			<li class="separator hidden-lg"></li>
		</ul>
	</div>
</div>
			<?php /**PATH /home/dh_skf5h8/workspace1.weavers-web.com/dictionary/resources/views/admn-template/pertials/header.blade.php ENDPATH**/ ?>