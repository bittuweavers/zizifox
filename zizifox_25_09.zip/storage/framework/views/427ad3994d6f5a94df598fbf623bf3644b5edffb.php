
<title>Home</title>

<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Start Css Link -->

<link rel="stylesheet" href="<?php echo e(url('forntend/css/bootstrap.min.css')); ?>" >
<link href="<?php echo e(url('forntend/css/style.css')); ?>" rel="stylesheet" type="text/css">

<!-- Start Font Link -->
<link href="https://fonts.googleapis.com/css?family=Lato:300i,400,400i,700,700i,900" rel="stylesheet">
<link href="<?php echo e(url('forntend/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<script src="<?php echo e(url('forntend/js/jquery-3.2.1.min.js')); ?>" type="text/javascript" ></script>

  
	<?php echo $__env->yieldContent('style'); ?>
	<?php /**PATH /home/ihfkir0o8bsv/public_html/betterthananative.com/resources/views/fornt-template/pertials/head.blade.php ENDPATH**/ ?>