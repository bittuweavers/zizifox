<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
    <div class="form">
        <div class="main-div cust">
        <div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="title">Create Language</h4>
			</div>
			<?php echo e(Form::open(['method' => 'POST','files' => true, 'route' => ['admin.languages.store']])); ?>

				<div class="panel-body">
					<div class="row">
						
						<div class="col-md-12 form-group">
						<?php echo e(Form::label('lang_name', 'Language Name*', ['class' => 'control-label'])); ?>


							<?php echo e(Form::text('lang_name', old('lang_name'), ['class' => 'form-control', 'placeholder' => 'Title', 'required' => ''])); ?>

							<p class="help-block"></p>
							<?php if($errors->has('lang_name')): ?>
								<p class="help-block">
									<?php echo e($errors->first('lang_name')); ?>

								</p>
							<?php endif; ?>
						</div>
											
					</div>				
					<div class="row">
						<div class="col-md-12 form-group">
							<?php echo e(Form::submit('save', ['class' => 'btn btn-primary'])); ?>

						</div>
					</div>
				</div>	
			<?php echo e(Form::close()); ?>


		</div>
	</div></div>	
	</div>
</div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/jquery.uploadfile.js')); ?>"></script>

<script>
jQuery(document).ready(function() {
	jQuery("#influencerslogo").uploadFile({
		url:"<?php echo e(url('admin/ajax-upload-photo')); ?>",
		fileName:"image",
		showPreview: true,
		showProgress: true,
		showError: false,
		showStatusAfterError: false,
		showFileCounter: false,
		multiple: false,
		showCancel: false,
		showAbort: false,
		dragDropStr: '',
		dragdropWidth: '28%',
		showFileSize: false,
		previewHeight: "60px",
		previewWidth: "auto",
		headers: {'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"},
		onSuccess: function (files, response, xhr, pd) {
			jQuery("#logo").val(response.response.file_path);
		}
	});

	jQuery("#descriptionimage").uploadFile({
		url:"<?php echo e(url('admin/ajax-upload-photo')); ?>",
		fileName:"image",
		showPreview: true,
		showProgress: true,
		showError: false,
		showStatusAfterError: false,
		showFileCounter: false,
		multiple: false,
		showCancel: false,
		showAbort: false,
		dragDropStr: '',
		dragdropWidth: '28%',
		showFileSize: false,
		previewHeight: "60px",
		previewWidth: "auto",
		headers: {'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"},
		onSuccess: function (files, response, xhr, pd) {
			jQuery("#description_image").val(response.response.file_path);
		}
	});


	     jQuery('#channel_list').select2({
            placeholder: "Choose Channels...",
            minimumInputLength: 2,
            ajax: {
                url: "<?php echo e(url('admin/channel/find')); ?>",
                dataType: 'json',
                data: function (params) {
                    return {
                        q: $.trim(params.term)
                    };
                },
                processResults: function (data) {
                    return {
                        results: data
                    };
                },
                cache: true
            }
        });

});	

var rand = function() {
    return Math.random().toString(36).substr(2); // remove `0.`
};

var token = function() {
    var tk = rand() + rand() + rand() + rand(); // to make it longer
    jQuery("#api_token").val(tk);
    
};

CKEDITOR.replace('description')
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/languages/create.blade.php ENDPATH**/ ?>