<!doctype html>
<html lang="en">
<head>
 <!------------Include header here------------------>
    <?php echo $__env->make('fornt-template.pertials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

	
  <?php echo $__env->yieldContent('content'); ?>	


</body>
 <!------------Include Script here------------------>	
 <?php echo $__env->make('fornt-template.pertials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH /home/ihfkir0o8bsv/public_html/betterthananative.com/resources/views/fornt-template/app.blade.php ENDPATH**/ ?>