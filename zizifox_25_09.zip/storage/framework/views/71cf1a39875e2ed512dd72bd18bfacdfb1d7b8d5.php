    <!--   Core JS Files   -->
    <script src="<?php echo e(url('admin/js/jquery.3.2.1.min.js')); ?>" type="text/javascript"></script>
	<script src="<?php echo e(url('admin/js/bootstrap.min.js')); ?>" type="text/javascript"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="<?php echo e(url('admin/js/light-bootstrap-dashboard.js?v=1.4.0')); ?>"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="<?php echo e(url('admin/js/demo.js')); ?>"></script>

	<!-- Owl Carousel! -->
	<script src="<?php echo e(url('admin/js/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/owl-call.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/moment.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/rome.standalone.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/material-datetime-picker.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/highcharts.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/fullcalendar.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/chart.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/appointment.js')); ?>"></script>

	<!-- Datatble -->


	<script src="<?php echo e(url('admin/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/dataTables.buttons.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/buttons.flash.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/buttons.html5.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/buttons.print.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/buttons.colVis.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/dataTables.select.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/select2.full.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/main.js')); ?>"></script>
		
	<script type="text/javascript">

	</script>
	<?php echo $__env->yieldContent('javascript'); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/betterthananative.com/resources/views/admn-template/pertials/script.blade.php ENDPATH**/ ?>