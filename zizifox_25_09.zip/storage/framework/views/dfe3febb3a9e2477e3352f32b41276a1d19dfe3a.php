<!doctype html>
<html lang="en">
<head>
 <!------------Include header here------------------>
    <?php echo $__env->make('admn-template.pertials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<style>
	.search-wrap select {
		border-color: #2d2c2c;
	}
	input.search-sbt {
		background-color: #00bfa5;
		border: none;
		color: #fff;
	}
	.search-wrap {
		padding: 20px 0;
	}
	input.search-sbt:hover,input.search-sbt:active,input.search-sbt:focus {
		background-color: #00bfa5;
		color: #fff;
	}
	.table td,th {
   		text-align: left;   
	}
	</style>	
</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="azure" data-image="<?php echo e(url('admin/img/sidebar-img.jpg')); ?>">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->
    <!------------Include Sidebar here------------------>
      <?php echo $__env->make('admn-template.pertials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <!------------Include Header here------------------>
			<?php echo $__env->make('admn-template.pertials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>

            <section class="angelProfile">
            <div class="container-fluid">
               	<!------------Include Body content here------------------>	
				<?php if(count($errors) > 0): ?>
					<div class = "alert alert-danger">
						<ul>
						   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <li><?php echo e($error); ?></li>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
			    <?php endif; ?>
				<?php if($message = Session::get('success')): ?>
					<div class="alert alert-success">
						<p><?php echo e($message); ?></p>
					</div>	
				<?php endif; ?>
				<?php if($messages = Session::get('error')): ?>
					<div class="alert alert-danger">
						<p><?php echo e($messages); ?></p>
					</div>	
				<?php endif; ?>
				
                <?php echo $__env->yieldContent('content'); ?>				
            </div>
        </section>


        <footer class="footer">
           <!------------Include Footer here------------------>	
		   <?php echo $__env->make('admn-template.pertials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>

    </div>
</div>


</body>
 <!------------Include Script here------------------>	
 <?php echo $__env->make('admn-template.pertials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admn-template/app.blade.php ENDPATH**/ ?>