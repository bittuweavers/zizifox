
<div class="container-fluid">
	<p class="copyright pull-right">
		&copy; <script>document.write(new Date().getFullYear())</script> <a href="<?php echo e(url('/')); ?>" target="_blank"/>Aroventa</a>, developed by <a href="http://weavers-web.com" target="_blank">Weavers Web Solutions Pvt. Ltd.</a>
	</p>
</div>
	
			<?php /**PATH /home/ihfkir0o8bsv/public_html/betterthananative.com/resources/views/admn-template/pertials/footer.blade.php ENDPATH**/ ?>