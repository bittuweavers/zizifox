<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-sm-12">

		    <div class="col-md-6 col-md-offset-3">
				<?php if(Session::has('message')): ?>
				<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
				<?php endif; ?>
            </div>
		<div class="table-responsive">
			<table class="table table-bordered table-striped">

				<thead>
					<tr>
						<th>Title</th>
						<th>Slug</th>
						<th>Date/Time Added</th>
						<th></th>
					</tr>
				</thead>

				<tbody>
					<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($page->title); ?></td>
						<td><?php echo e($page->page_slug); ?></td>
						<td><?php echo $page->created_at; ?></td>
						<td>
							<a href="<?php echo e(url('/').'/'.$page->page_slug); ?>" class="btn btn-success pull-left" style="margin-right: 3px;" target="_blank">View</a>
							<a href="<?php echo e(url('admin/pages/edit/'.$page->id)); ?>" class="btn btn-info pull-left" style="margin-right: 3px;">Edit</a>
							<?php /*
							{!! Form::open(array(
								'style' => 'display: inline-block;',
								'method' => 'DELETE',
								'onsubmit' => "return confirm('Are you sure ?');",
								'route' => ['admin.pages.destroy', $page->id])) !!}
								{!! Form::submit('Delete', array('class' => 'btn btn-danger')) !!}
							{!! Form::close() !!} */ ?>

							
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			
			</table>
			<?php echo e($pages->links()); ?>

		</div>

	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/page/index.blade.php ENDPATH**/ ?>