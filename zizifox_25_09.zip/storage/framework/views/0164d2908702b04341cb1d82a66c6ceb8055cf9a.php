		<style>
		.logo img {
			height: auto;
		}
		</style>
		<div class="sidebar-wrapper">
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>" class="simple-text">
                	<?php $headerLogo = \App\Models\Settings::getSettings('header-logo');?>
					<img src="<?php echo e($headerLogo); ?>" width="80" >
                </a>
            </div>

            <ul class="nav" id="sidebar-menu">
				<?php if(Request::is('admin/videos/add')): ?>
					<?php $videosaddmenuClass = 'active'; ?>
				<?php else: ?>
					<?php $videosaddmenuClass = ''; ?>
				<?php endif; ?>

				<?php if(Request::is('admin/videos/list')): ?>
					<?php $videoslistmenuClass = 'active'; ?>
				<?php else: ?>
					<?php $videoslistmenuClass = ''; ?>
				<?php endif; ?>

				<?php if(Request::is('admin/search/list')): ?>
					<?php $searchlistmenuClass = 'active'; ?>
				<?php else: ?>
					<?php $searchlistmenuClass = ''; ?>
				<?php endif; ?>
				<?php if(Request::is('admin/settings')): ?>
					<?php $settingmenuClass = 'active'; ?>
				<?php else: ?>
					<?php $settingmenuClass = ''; ?>
				<?php endif; ?>
							
				<li class="<?php echo e($videosaddmenuClass); ?>">
					<a href="<?php echo e(url('admin/videos/add')); ?>">
						<p class="title">Add a New Video</p>
					</a>
				</li>
				<li class="<?php echo e($videoslistmenuClass); ?>">
					<a href="<?php echo e(url('admin/videos/list')); ?>">
						<p class="title">Stored Video</p>
					</a>
				</li>
				<li class="<?php echo e($searchlistmenuClass); ?>">
					<a href="<?php echo e(url('admin/search/list')); ?>">
						<p class="title">Search Log</p>
					</a>
				</li>
				<li class="<?php echo e($settingmenuClass); ?>">
					<a href="<?php echo e(url('admin/settings')); ?>">
						<p class="title">Settings</p>
					</a>
				</li>
                  				
            </ul>
    	</div>
		<?php $__env->startSection('javascript'); ?>
		  
		<?php $__env->stopSection(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/betterthananative.com/resources/views/admn-template/pertials/sidebar.blade.php ENDPATH**/ ?>