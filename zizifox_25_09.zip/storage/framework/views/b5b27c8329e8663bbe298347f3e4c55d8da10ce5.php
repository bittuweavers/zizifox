<!doctype html>
<html lang="en">
<head>
 <!------------Include header here------------------>
    <?php echo $__env->make('fornt-template.pertials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-138940807-3"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-138940807-3');
    </script>

    <!-- Google Adsense -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-9358295083964619",
    enable_page_level_ads: true
  });
</script>

</head>
<body>

	
  <?php echo $__env->yieldContent('content'); ?>	

 <?php echo $__env->make('fornt-template.pertials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
 <!------------Include Script here------------------>	
 <?php echo $__env->make('fornt-template.pertials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/fornt-template/app.blade.php ENDPATH**/ ?>