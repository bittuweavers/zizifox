
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	
	<script src="<?php echo e(url('forntend/js/popper.min.js')); ?>" type="text/javascript" ></script>
	<script src="<?php echo e(url('forntend/js/bootstrap.min.js')); ?>" type="text/javascript" ></script>
	<script type="text/javascript" src="https://www.youtube.com/iframe_api" ></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>
    <script type="text/javascript">
  
  $(document).ready(function () {
  $( "#play-btn-video" ).click(function() {
 		 if($('#play-btn').hasClass('fa-play')){
            player.playVideo();

 		 }
        if ($('#play-btn').hasClass('fa-pause')){
            player.pauseVideo();
        }
});
})
</script>
	<?php echo $__env->yieldContent('javascript'); ?><?php /**PATH /home/dh_skf5h8/workspace1.weavers-web.com/dictionary/resources/views/fornt-template/pertials/script.blade.php ENDPATH**/ ?>