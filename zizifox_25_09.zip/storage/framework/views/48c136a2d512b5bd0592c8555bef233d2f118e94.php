

<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="container-fluid">
			<div class="search-wrap">
				<div class="row">
				<h4 style="text-align: center;">The Search Log</h4>
				</div>
			</div>
			<div class="row">

			</div>
			<div class="row">
				<div class="col-md-12">

					<div class="card">
						<?php $no = 1; ?>
						<div class="content table-responsive table-full-width">
							<table  class="table table-bordered table-hover table-striped <?php echo e(count($search_result) > 0 ? 'datatable' : ''); ?>">
								<thead>
									
									<th>Sl No</th>
									<th>The Search Log</th>
									<th>Date Time</th>
									<th>Status</th>
									<th>Action</th>
									
								</thead>
								<tbody>
									<?php if(isset($search_result) && is_object($search_result)): ?>
										<?php $__currentLoopData = $search_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr data-entry-id="<?php echo e($val->id); ?>">
												
												<td><?php echo e($no); ?></td>
												<td><?php echo e($val->search_text); ?></td>
												<td><?php echo e(date('H:i:s d/m/Y',strtotime($val->search_date))); ?></td>
												<td><?php if($val->search_found_status=='1'): ?> <?php echo e('Found'); ?> <?php else: ?> <?php echo e('Not Found'); ?> <?php endif; ?></td>
												<td colspan="2">

														<?php echo Form::open(array(
															'style' => 'display: inline-block;',
															'method' => 'DELETE',
															'onsubmit' => "return confirm('Are you sure ?');",
															'route' => ['admin.search.destroy', $val->id])); ?>

															<?php echo Form::submit('Delete', array('class' => 'btn btn-xs btn-danger')); ?>

														<?php echo Form::close(); ?>

			                                       	
												</td>
											</tr>
											<?php $no++; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									<?php endif; ?>
								</tbody>	
							</table>
						
                        </div>

                    </div>
                   
                </div>
            </div>
        </div>

    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script>

    	$(document).ready(function(){
        	
            $('.video_status').on('click', function(event){
            	if(confirm('Are you sure to change the status?')){

                id = $(this).data('id');
                var $this = $(this);
                $.ajax({
                    type: 'POST',
                    url:"<?php echo e(URL::route('admin.videos.changeStatus')); ?>",
					data: {
					        "_token": "<?php echo e(csrf_token()); ?>",
					        "id": id
					        },
                    success: function(data) {
                    	$this.html(data);
                        // empty
                    },
                });
            }
            });
          
        });

 	</script>
<?php $__env->stopSection(); ?>	





<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Dictionary/resources/views/admin/search/index.blade.php ENDPATH**/ ?>