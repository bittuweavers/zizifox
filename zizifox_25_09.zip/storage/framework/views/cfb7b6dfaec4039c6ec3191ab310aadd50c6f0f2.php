<?php $__env->startSection('content'); ?>
			<div class="row">

				<div class="col-sm-12">
					<table class="table table-bordered table-striped">
			    		<thead>
			      			<tr>
			        			<h4 style="text-align: center;"></h4>
			      			</tr>
			    		</thead>					
			    		<tbody>
			      		
			        		<tr> 
			        			<td>Title</td>
			        			<td><?php echo e($influencer->title); ?></td>
			         		</tr>
			         		<tr> 
			        			<td>Description</td>
			        			<td><?php echo e($influencer->description); ?></td>
			         		</tr>
			         		<tr> 
			        			<td>Channel Name</td>
			        			<td><?php echo $channel_name = \App\Models\Channel::get_channel_name( $influencer->channels_id);?></td>
			         		</tr>
			         		<tr> 
			        			<td>Logo</td>
			        			<?php if($influencer->logo): ?>
			        			<td><img src="<?php echo e($influencer->logo); ?>" alt="<?php echo e($influencer->title); ?>"></td>
			        			<?php else: ?>
			        			<td></td>
			        			<?php endif; ?>
			         		</tr>
			         		<tr> 
			        			<td>Site Url</td>
			        			<td><a target="_blank" href="<?php echo e($influencer->site_url); ?>"><?php echo e($influencer->site_url); ?></a></td>
			         		</tr>
			         		<tr> 
			        			<td>Subscription Custom Url</td>
			        			<td><?php echo e($influencer->subscription_custom_url); ?></td>
			         		</tr>
			         		<tr> 
			        			<td>Youtube Channel Url</td>
			        			<td><a target="_blank" href="<?php echo e($influencer->youtube_channel_url); ?>"><?php echo e($influencer->youtube_channel_url); ?></a></td>
			         		</tr>
			         		<tr> 
			        			<td>Url</td>
			        			<td><a target="_blank" href="<?php echo e(route('influencers',[$influencer->slug])); ?>"><?php echo e(route('influencers',[$influencer->slug])); ?></a></td>
			         		</tr>							
						</tbody>
			      	</table>					
				</div>			
			</div>	
	<style>
	ul.user-info {
		padding: 0;
	}
	.user-info>li {
		list-style: none;
		padding: 3px;
	}
	.user-info>li>strong {
		margin-right: 10px;
	}
	</style>

<?php $__env->stopSection(); ?>	
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/admin/influencers/show.blade.php ENDPATH**/ ?>