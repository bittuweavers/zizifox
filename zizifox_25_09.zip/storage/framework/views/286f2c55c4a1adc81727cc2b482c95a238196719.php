

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
    <div class="form">
        <div class="main-div">
        <div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="title">Add Video</h4>
			</div>
			<?php echo e(Form::open(['method' => 'POST','files' => true,'route' => ['admin.videos.store']] )); ?>

				<div class="panel-body">
					<div class="row">
						<div class="col-md-12">
							<div class="col-xs-12 form-group">
								<?php echo e(Form::label('video_id_url', 'Please paste youtube link or video id*', ['class' => 'control-label'])); ?>


								<?php echo e(Form::text('video_id_url', old('video_id'), ['class' => 'form-control', 'placeholder' => 'Youtube Video Id OR URl', 'required' => ''])); ?>

								<p class="help-block"></p>
							
							</div>
					
						</div>
						</div>						
					
	
					<div class="row">
						<div class="col-md-12"></div>
											
					</div>				
					<div class="row">
						<div class="col-xs-12 form-group">
							<?php echo e(Form::submit('save', ['class' => 'btn btn-primary'])); ?>

						</div>
					</div>
				</div>	
			<?php echo e(Form::close()); ?>


		</div>
	</div></div>	
	</div>
</div>

<style>
.main-div {
    background: #ffffff none repeat scroll 0 0;
    border-radius: 2px;
    margin: 10px auto 30px;
    max-width: 100%;
    padding: 50px 70px 70px 71px;
}
</style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Dictionary/resources/views/admin/videos/create.blade.php ENDPATH**/ ?>