

<?php $__env->startSection('content'); ?>
			<div class="row">

				<div class="col-sm-12">
								
				</div>			
			</div>	
	<style>
	ul.user-info {
		padding: 0;
	}
	.user-info>li {
		list-style: none;
		padding: 3px;
	}
	.user-info>li>strong {
		margin-right: 10px;
	}
	</style>

<?php $__env->stopSection(); ?>	
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admn-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Dictionary/resources/views/admin/users/show.blade.php ENDPATH**/ ?>