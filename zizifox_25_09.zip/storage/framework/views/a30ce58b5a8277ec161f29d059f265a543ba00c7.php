
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	
	<script src="<?php echo e(url('forntend/js/popper.min.js')); ?>" type="text/javascript" ></script>
	<script src="<?php echo e(url('forntend/js/bootstrap.min.js')); ?>" type="text/javascript" ></script>
	<script type="text/javascript" src="https://www.youtube.com/iframe_api" ></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>

	<?php echo $__env->yieldContent('javascript'); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/betterthananative.com/resources/views/fornt-template/pertials/script.blade.php ENDPATH**/ ?>