<?php $__env->startSection('content'); ?>

<!-- Start Banner Section -->
<section class="banner_cover_sec" <?php if($banner){ ?> style="background: url('<?php echo e($banner->banner_url); ?>');background-repeat: no-repeat;background-size: cover;background-position: center center;" <?php } ?> >
  <div class="container-fluid">
    <div class="logo_sec">
       <?php $headerLogo = \App\Models\Settings::getSettings('header-logo');?>
                         <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e($headerLogo); ?>" alt="Logo"></a>
    </div>
     <?php echo e(Form::open(['id'=>'search_form','method' => 'GET','route' => ['home.search.video']] )); ?>

    <div class="search_sec">
      <div class="search">
        <?php if(isset($_GET['search'])): ?>
        <?php $seacrh = $_GET['search'];  ?>
        <?php else: ?> 
        <?php  $seacrh = "";  ?>
        <?php endif; ?> 

         <?php if(isset($_GET['language'])): ?>
        <?php $lan = $_GET['language'];  ?>
        <?php else: ?> 
        <?php  $lan = "us";  ?>
        <?php endif; ?>     

         <input name="search" type="search" placeholder="Enter a word" value="<?php echo e($seacrh); ?>" autocomplete="off" maxlength="100" class="s-input js-search-field " required>
        
        <div class="option_box">
          <select data-placeholder="Choose a Language..." id="lan-select" name="language">
                  <?php if($language->count()>0): ?>
                <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($val->lang_code=='en'){
                        $lang='us';
                        }else{
                        $lang=$val->lang_code;
                        } 
                  ?> 
                  <option value="<?php echo e($lang); ?>" <?php if($lan==$lang){ echo "selected"; } ?>><?php echo e($val->lang_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <?php else: ?>
                  <option value="us" <?php if($lan==$lang){ echo "selected"; } ?>>US</option>      
                <?php endif; ?> 
          </select>
        </div>
      </div>
      <div class="button_sec">
        <button type="submit" class="btn_submit">Search</button>
      </div>
      <?php if($search_count>49): ?>
                            <?php echo NoCaptcha::renderJs(); ?>

                             <?php echo NoCaptcha::display(); ?>

                             <div class="error_captcha"></div> 
                         <?php endif; ?>
    </div>
      <?php echo e(Form::close()); ?>   
  </div>
</section>
<!-- End Banner Section -->

<!-- Start View Section -->
<section class="view_sec">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-2 left_sec left_first_sec">
        <div class="img_sec">
          <?php $searchpageleftads = \App\Models\Settings::getSettings('search-page-left-ads');?>
                  <?php echo $searchpageleftads; ?>

        </div>
      </div>
      <div class="col-md-8 left_sec">
        <h3>How to Pronounce <?php echo e($_GET['search']); ?> in English(<span id="page"><?php echo e($page); ?></span> out <?php echo e($video_count); ?> )</h3>
         <div class="ajax_load" ><img src="<?php echo e(url('forntend/images/loading.gif')); ?>"></div>
          <div class="ajx-result">
                  <?php echo $__env->make('forntend.ajax_search_result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           </div>
      </div>
      <div class="col-md-2 right_sec">
        <div class="img_sec">
          <?php $searchpagerightads = \App\Models\Settings::getSettings('search-page-right-ads');?>
                  <?php echo $searchpagerightads; ?>

        </div>
      </div>
    </div>
  <div>
</section>
<!-- End View Section -->
 
 <?php if($search_count>49): ?>
   <script type="text/javascript">
     
     $('form').on('submit', function(e) {
  if(grecaptcha.getResponse() == "") {
    $('.error_captcha').html('Captcha is required');
   // e.preventDefault();
   // alert("You can't proceed!");
    return false;
  } else {
  //  alert("Thank you");
  }
});
   </script>
  

 <?php endif; ?>
<script type="text/javascript">
   $(document).ready(function()
    {
        $(document).on('click', '.pagination',function(event)
        {
              event.preventDefault();
             
             var page = $(this).find('a:first').data('page');
             var search = $(this).find('a:first').data('search');
             var id = $(this).find('a:first').data('id');
            getData(page,search,id);
        });

        $(document).ajaxStart(function(){
          $(".ajax_load").css("display", "block");
          $('a').attr('disabled',true);
        });
        $(document).ajaxComplete(function(){
          $(".ajax_load").css("display", "none");
           $('a').attr('disabled',false);
        });

  
    });
  
    function getData(page,search,id){

        var lang  = '<?php echo $lan; ?>';
        jQuery.ajax(
        {
            url: "<?php echo e(url('/ajax-pagination')); ?>",
              type: "get",
             data: { page: page,search:search,id:id,lang:lang },
            datatype: "html"
        }).done(function(data){
            $(".ajx-result").empty().html(data);
            onYouTubeIframeAPIReady();
            $("#page").text(page);
        }).fail(function(jqXHR, ajaxOptions, thrownError){
              alert('No response from server');
        });
    }

</script>
 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('fornt-template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihfkir0o8bsv/public_html/zizifox.com/resources/views/forntend/search.blade.php ENDPATH**/ ?>