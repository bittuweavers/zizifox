<title>Home</title>

<!-- Required meta tags -->
<meta charset="utf-8">
<link rel="icon" type="image/png" href="{{ url('admin/img/favicon.ico')}}">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Start Css Link -->

<link rel="stylesheet" href="{{ url('forntend/css/bootstrap.min.css')}}" >
<link href="{{ url('forntend/css/style.css')}}" rel="stylesheet" type="text/css">
<link href="{{ url('forntend/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css">


<!-- Start Font Link -->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700&display=swap" rel="stylesheet">

<script src="{{ url('forntend/js/jquery-3.2.1.min.js')}}" type="text/javascript" ></script>

  
	@yield('style')
	