
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	
	<script src="{{url('forntend/js/popper.min.js')}}" type="text/javascript" ></script>
	<script src="{{url('forntend/js/bootstrap.min.js')}}" type="text/javascript" ></script>
	<script type="text/javascript" src="https://www.youtube.com/iframe_api" ></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>

	@yield('javascript')