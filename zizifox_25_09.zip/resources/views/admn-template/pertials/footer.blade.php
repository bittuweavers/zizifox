
<div class="container-fluid">
	<p class="copyright pull-right">
		&copy; <script>document.write(new Date().getFullYear())</script> <a href="{{url('/')}}" target="_blank"/>Aroventa</a>, developed by <a href="http://weavers-web.com" target="_blank">Weavers Web Solutions Pvt. Ltd.</a>
	</p>
</div>
	
			